# LongCovidStudyathon: Feasiblity counts

This is a script to run to get the Feasibility counts for the Long Covid and PASC Studyathon, Oxford April 2023. \
You should just interact with the file `CodeToRun.R`. \
Please clone the repository to your local and run all the lines in `CodeToRun.R`, after adding your own database information.\
You should get a .zip file in the folder `Results`, which you should share. \
Thank you for running the study!
