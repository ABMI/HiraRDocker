# COVID-19 vaccination and the risk of post COVID-19 thromboembolic and cardiovascular complications: a multinational cohort study
### The repository contains the analysis code of the study on COVID-19 vaccination effect on thromboembolic and cardiovascular complications following SARS-CoV-2 infection.
Analysis code can be tailored to vaccination roll-out campaing in the UK, Spain and Estonia. 
To run the code, fill the connection details in the script `CodeToRun.R` and execute the script.
